#include <Wire.h>
#include <NewPing.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

byte bar1[8] = {
  B00000,
  B00000,
  B00000,
  B00000,
  B00000,
  B00000,
  B11111,
  B11111
};

byte bar2[8] = {
  B00000,
  B00000,
  B00000,
  B00000,
  B00000,
  B11111,
  B11111,
  B11111
};

byte bar3[8] = {
  B00000,
  B00000,
  B00000,
  B00000,
  B11111,
  B11111,
  B11111,
  B11111
};

byte bar4[8] = {
  B00000,
  B00000,
  B00000,
  B11111,
  B11111,
  B11111,
  B11111,
  B11111
};

byte bar5[8] = {
  B00000,
  B00000,
  B11111,
  B11111,
  B11111,
  B11111,
  B11111,
  B11111
};

byte bar6[8] = {
  B00000,
  B11111,
  B11111,
  B11111,
  B11111,
  B11111,
  B11111,
  B11111
};
byte bar7[8] = {
  B11111,
  B11111,
  B11111,
  B11111,
  B11111,
  B11111,
  B11111,
  B11111
};

//--------------- Sensors ----------------
#define WATER_SENSOR_PIN  5

//--------------- Switches ----------------
#define MOTOR_SWITCH       2
#define BYPASS_SWITCH      3
#define SWITCH3_PIN        4


//--------------- Outputs ----------------
#define RELAY_PIN         6
#define BUZZER_PIN        7

//--------------- Ultrasonic Sensor -------
#define TRIGGER_PIN       8
#define ECHO_PIN          9
#define MAX_DISTANCE     500
int tankEmpty = 150;   // cm when tank empty
int tankFull  = 23;    // cm when tank full
int distance;
int waterLevel;
int i=0;
int j=0;
int flag=0;
NewPing sonar(TRIGGER_PIN, ECHO_PIN, MAX_DISTANCE);

//--------------- RS485 -------------------
#define RS485_RO_PIN      10   // Receive
#define RS485_DI_PIN      11   // Transmit
#define RS485_DE_RE_PIN   12   // Direction Control








void setup()
{
  lcd.init();
  lcd.backlight();
  
    //-------------Bar Graph Bytes----------
    lcd.createChar(1, bar1);
    lcd.createChar(2, bar2);
    lcd.createChar(3, bar3);
    lcd.createChar(4, bar4);
    lcd.createChar(5, bar5);
    lcd.createChar(6, bar6);
    lcd.createChar(7, bar7);
    
  
    //------------- Input Pins -------------
    pinMode(WATER_SENSOR_PIN, INPUT);

    pinMode(MOTOR_SWITCH, INPUT_PULLUP);
    pinMode(BYPASS_SWITCH, INPUT_PULLUP);
    pinMode(SWITCH3_PIN, INPUT_PULLUP);
    

     //------------- Output Pins ------------
    pinMode(RELAY_PIN, OUTPUT);
    pinMode(BUZZER_PIN, OUTPUT);
    pinMode(RS485_DE_RE_PIN, OUTPUT);

    //------------- Default States ---------
    digitalWrite(RELAY_PIN, LOW);
    digitalWrite(BUZZER_PIN, HIGH);

    // RS485 Receive Mode Default
    digitalWrite(RS485_DE_RE_PIN, LOW);

  lcd.setCursor(0, 0);
  lcd.print("Automatic water");
  lcd.setCursor(0, 1);
  lcd.print("pumping system");
  delay(2000);
  digitalWrite(BUZZER_PIN, LOW);
  lcd.clear();
}

void loop()
{
  // Convert distance to water level %
  distance = sonar.ping_cm();
  waterLevel = map(distance,tankEmpty,tankFull,100,0);
  waterLevel = constrain(waterLevel, 0, 100);

  lcd.setCursor(8,0);
  lcd.print("Lvl:");
  lcd.print(waterLevel);
  lcd.print("%   ");
  lcd.setCursor(0,1);
  lcd.print("LO ");
  lcd.setCursor(13,1);
  lcd.print(" HI");

  // graph call
  BAR_GRAPH();


  
  
// PUMP ON OFF FUCTION CALL
  if((digitalRead(MOTOR_SWITCH)==LOW)&&(flag==0))
  {
   PUMP_ON();
   if(flag==0)
   {
     lcd.clear();
     for(j=5;j>=0;j--)
     {
       lcd.setCursor(0,0);
       lcd.print("Water flow check");
       lcd.setCursor(3,1);
       lcd.print("  in: ");
       lcd.print(j);
       lcd.print(" Sec");
       delay(1000);
       if((digitalRead(WATER_SENSOR_PIN)==HIGH)&&(flag==0))
       {
         flag=1;
         break;
       }
       else if((j==0)&&(flag==0))
       {
        flag=3;
        break;
       }
     }
    } 
  }
  else
  {
   flag=0;
   PUMP_OFF();   
  }
  
}

void PUMP_ON()
{
  lcd.setCursor(0, 0);
  lcd.print("PMP ON  ");
  digitalWrite(RELAY_PIN, HIGH);

}
void PUMP_OFF()
{
  lcd.setCursor(0, 0);
  lcd.print("PMP OFF ");
  digitalWrite(RELAY_PIN, LOW);

}
void BAR_GRAPH()
{
    lcd.setCursor(3,1);
    // Convert water level into 0-10 blocks
    int totalBars = waterLevel / 10;

    for(int i = 0; i < 10; i++)
    {
      if(i <= totalBars)
      {
        if(i<7)
        {
          lcd.write(byte(i+1)); 
        }
        else
        {
          lcd.write(byte(7)); 
        }
        if(waterLevel<10)
        {
          lcd.setCursor(3,1);
          lcd.print(" ");
          delay(200);
          lcd.setCursor(3,1);
          lcd.write(byte(1));
          delay(200);
        }
      }
      else
      {
        lcd.print(" ");       // Empty block
      }
    }
}

